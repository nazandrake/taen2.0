stand-in readme
